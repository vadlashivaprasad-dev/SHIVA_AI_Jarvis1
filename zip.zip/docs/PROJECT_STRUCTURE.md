# ShivaAI Jarvis Project Structure

This repository now follows a small monorepo layout that can grow into the larger multi-service plan already described in the project documents.

```text
apps/
  web/                 Vite React client
services/
  gateway/             FastAPI gateway and public API surface
infra/
  monitoring/          Prometheus and future observability config
scripts/               Developer automation
tests/                 Cross-project smoke tests
docs/                  Architecture, roadmap, and implementation documents
legacy/scaffold/       Preserved original backend/frontend scaffold
```

The current implementation keeps the runtime intentionally focused:

- `services/gateway` exposes `/health`, `/api/v1/health`, persistent chat sessions, and chat completions.
- `services/gateway` stores conversations in SQLite through `DATABASE_PATH`.
- `services/gateway` exposes Server-Sent Events through `/api/v1/chat/completions/stream`.
- `services/gateway` exposes memory CRUD/search through `/api/v1/memory`.
- `services/gateway` uses `LLM_PROVIDER=local` by default, with an OpenAI-compatible provider available through env configuration.
- `apps/web` connects to the gateway through `VITE_API_URL`, reopens saved conversations, and manages semantic memory.
- `docker-compose.yml` runs the gateway, frontend, and local platform dependencies.
- `.github/workflows/ci.yml` runs backend smoke tests and builds the web app.

Future service folders should go under `services/<service-name>` once they have a runnable `Dockerfile`, `requirements.txt`, and `src/main.py`.
